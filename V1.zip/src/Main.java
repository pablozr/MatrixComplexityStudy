public class Main {
    public static void main(String[] args) {
        MatrizEsparsaEstatica matriz = new MatrizEsparsaEstatica(3, 3);

        // Inserir elementos
        matriz.insertElement(0, 0, 5);
        matriz.insertElement(1, 1, 3);
        matriz.insertElement(1, 0, 7);

        // Imprimir matriz
        matriz.printMatriz();


    }
}